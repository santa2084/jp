<?php get_header(); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-xs-12">
        <?php if(have_posts()) : ?>
          <?php
          while(have_posts()) :
            the_post();
            ?>
        <div class="article">
        <h1>
        <?php the_title(); ?>
        </h1>
          <?php the_content(); ?>
        </div>
        <?php endwhile; ?>
        <?php endif; ?>

      </div>

      <div class="col-md-4 col-xs-12">
        <?php get_sidebar(); ?>
      </div>

    </div>
  </div>
<?php get_footer(); ?>