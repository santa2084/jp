<?php get_header(); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-xs-12">
        <div class="article">
         <div class="news">
           <h4>新着記事</h4>
           <ul>
            <?php if(have_posts()) : ?>
              <?php
              while(have_posts()) :
                the_post();
                ?>
             <li>
                <?php if(has_post_thumbnail()): ?>
                  <?php the_post_thumbnail('archive_thumbnail'); ?>
                  <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/no.jpg">
                  <?php endif;?>
               <div class="come">
                 <div class="title">
                 <?php the_title(); ?>
                 </div>
                 <a href="<?php the_permalink(); ?>"><?php the_excerpt(); ?></a>
                 <?php the_tags(
                '<a><p>','<time></time>','</p></a>'
              ); ?>
               </div>   
             </li>
             <?php endwhile; ?>
             <?php endif; ?>
           </ul>
           <?php the_posts_pagination(
        array(
          'prev_text' => '&lt;<span class="sr-only">前</span>',
          'next_text' => '<span class="sr-only">次</span>&gt;',
        )
       ); ?>
         </div>
        </div>
      </div>

      <div class="col-md-4 col-xs-12">
        <?php get_sidebar(); ?>
      </div>

    </div>
  </div>
<?php get_footer(); ?>
  