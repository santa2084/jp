<div class="sidebar">
          <div class="profile">
            <p>プロフィール</p>
            <p><span>ぽてっと</span></p>
            <div class="image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/author.jpg" alt="author">
            </div>
            <p>18歳ブロガー｜twitterマーケティング実践中｜投資歴2ヶ月｜S&P500にインデックス投資をしています！｜サイトの運営の仕方｜twitter運用の仕方｜をブログで発信していきます！｜DMで相談に乗るので気軽に連絡ください。</p>
          </div>
          <div class="archive">
            <p>アーカイブ</p>
            <ul>
            <?php
      wp_nav_menu(
        array(
          'theme_location' => 'archive',
        )
        );
      ?>
            </ul>
          </div>
          <div class="navi">
            <nav id="navigestion">
              <ul>
              <?php
      wp_nav_menu(
        array(
          'theme_location' => 'navi-midium',
        )
        );
      ?>
              </ul>
            </nav>
          </div>
          
        </div>