<div class="footer">
    <div class="rank">
      <h4>ランダム記事</h4>
      <ul>
      <?php
      $pote_args = array(
        'orderby' => 'rand',
        'posts_per_page' => 3,
      );
      ?>
      <?php
      $pote_news_query = new WP_Query($pote_args);
      if($pote_news_query->have_posts()) :
      ?>
      <?php
      while($pote_news_query->have_posts()) :
        $pote_news_query->the_post();
      ?>
        <li>
        <?php if(has_post_thumbnail()): ?>
                  <?php the_post_thumbnail('archive_thumbnail'); ?>
                  <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/no.jpg">
                  <?php endif;?>
               <div class="come">
                 <div class="title">
                 <?php the_title(); ?>
                 
                 </div>
                 <a href="<?php the_permalink(); ?>"><?php the_excerpt(); ?></a>
                 <?php the_tags(
                '<a><p>','<time></time>','</p></a>'
              ); ?>
               </div>      
        </li>
        <?php endwhile;
        wp_reset_postdata();
         ?>
        <?php endif; ?>
      </ul>
    </div>
    <div class="news">
      <h4>新着記事</h4>
      <ul>
      <?php
      $pote_args = array(
        'post_type' => 'post',
        'posts_per_page' => 3,
      );
      ?>
      <?php
      $pote_news_query = new WP_Query($pote_args);
      if($pote_news_query->have_posts()) :
      ?>
      <?php
      while($pote_news_query->have_posts()) :
        $pote_news_query->the_post();
      ?>
        <li>
        <?php if(has_post_thumbnail()): ?>
                  <?php the_post_thumbnail('archive_thumbnail'); ?>
                  <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/no.jpg">
                  <?php endif;?>
               <div class="come">
                 <div class="title">
                 <?php the_title(); ?>
                 </div>
                 <a href="<?php the_permalink(); ?>"><?php the_excerpt(); ?></a>
                 <?php the_tags(
                '<a><p>','<time></time>','</p></a>'
              ); ?>
               </div>   
        </li>
        <?php endwhile;
        wp_reset_postdata();
         ?>
        <?php endif; ?>
      </ul>
    </div>
    <div class="twitter">
      <h4>twitter</h4>
      <div class="timeline">
        <a class="twitter-timeline" data-lang="ja" data-width="300" data-height="400" data-align="center" href="https://twitter.com/himatubusi208?ref_src=twsrc%5Etfw">Tweets by himatubusi208</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
      </div>
    </div>
  </div>
  <footer>
    <div class="menu">
      <div class="logo-image">
      <?php bloginfo('name'); ?>
      </div>
      <div class="footer-inner">
        <ul id="site">
        <?php
      wp_nav_menu(
        array(
          'theme_location' => 'navi-bottom-1',
        )
        );
      ?>
        </ul>
        <ul id="blog">
        <?php
      wp_nav_menu(
        array(
          'theme_location' => 'navi-bottom-2',
        )
        );
      ?>
        </ul>
      </div>
    </div>
    <div class="copy">
      <p>copy-right-<?php bloginfo('name'); ?></p>
    </div>
    
  </footer>
  <script src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/js/bootstrap.min.js"></script>
  <?php wp_footer(); ?>
</body>
</html>