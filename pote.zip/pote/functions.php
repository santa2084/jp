<?php
function pote_theme_setup(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  register_nav_menus( array(
    'navi' => 'ナビ',
    'archive' => 'アーカイブ',
    'navi-midium' => 'ナビ真ん中',
    'navi-bottom-1' => '下のナビ1',
    'navi-bottom-2' => '下のナビ2',
  ));
}

add_action('after_setup_theme','pote_theme_setup');

?>
