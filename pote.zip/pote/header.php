<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/css/bootstrap.min.css">
  <!-- css -->
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/main.css">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/footer.css">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/header.css">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/sidebar.css">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/style.css">
  <!-- css -->
  <!-- fontawesome -->
  <script src="https://kit.fontawesome.com/62437e8283.js" crossorigin="anonymous"></script>
  <!-- fontawesome -->
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
  <header>
    <div class="inner">
      <h1 id="logo">
        <?php bloginfo('name'); ?>
      </h1>
      <div class="opinion">
        <p><?php bloginfo('description'); ?></p>
      </div>
    </div>
    <nav id="nav">
      <ul>
        <li>
        <?php
      wp_nav_menu(
        array(
          'theme_location' => 'navi',
        )
        );
      ?>
        </li>
       
      </ul>
    </nav>
  </header>