<?php get_header(); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-xs-12">
        <div class="main">
          <h1 id="fadein" class="fadein-before">
            <?php if(is_month()): ?>
              <?php echo get_the_date('Y年n月'); ?>
              <?php else: ?>
            <?php single_term_title(); ?>
            <?php endif; ?>
          </h1>
          <?php if(have_posts()) : ?>
            <?php
            while(have_posts()):
              the_post();
              ?>

           <div class="lesson" id="top">
            <?php
            $poteto_post_year = get_the_date('Y');
            $poteto_post_month = get_the_date('m');
            ?>
            <a href="<?php echo get_month_link('$poteto_post_year','$poteto_post_month'); ?>">
              <p class="center"><time datetime="<?php echo get_the_date('y-m-d'); ?>"><?php echo get_the_date(); ?></time></p>
              <h3><?php the_title(); ?></h3>
              <div class="images">
              <?php if(has_post_thumbnail()): ?>
                  <?php the_post_thumbnail('archive_thumbnail'); ?>
                  <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/no.jpg">
                  <?php endif;?>        
              </div>
              <p id="fadeinm1" class="fadein-before">今回は,高校生でもできるアフェリエイトの始め方について、まとめてみました！よかったら参考にしてください。</p>
              <div class="read">
                <a href="<?php the_permalink(); ?>">READ MORE</a>
              </div>
            </a>     
           </div>
           

       <?php endwhile; ?>
       <?php endif; ?>
       <?php the_posts_pagination(); ?>
       </div>
      </div>
      <?php get_sidebar(); ?>
    </div>
  </div>
  <?php get_footer(); ?>