<div class="col-md-4 col-xs-12">

        <div class="side">

          <div class="archive">
            <h2 id="fadein2" class="fadein-before">archive</h2>
            <ul id="fadeinp1" class="fadein-before">
              <a>
              <?php
      wp_nav_menu(
        array(
          'theme_location' => 'archive',
        )
        );
      ?>
              </a>
            
            </ul>
          </div>

          <div class="profile">
            <h2 id="fadein3" class="fadein-before">profile</h2>
            <div class="image">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/author.jpg" width="70px" height="70px">
            </div>
            <p id="fadeinp2" class="fadein-before">こんにちは！高校生ブロガーの【ぽてっと】です。今プログラミングにハマっています。blogでは、プログラミングのことや、自分の生活のことについて話していこうと思います！</p>
          </div> 

          <div class="portfolio">
            <h2 id="fadein4" class="fadein-before">portfolio</h2>
            <div class="port">
              <ul id="fadeinp3" class="fadein-before">
                <li><?php
                      wp_nav_menu(
                        array(
                          'theme_location' => 'side-menu',
                       )
                        );
                      ?>
                </li>
              </ul>
            </div>
            
          </div>

          <div class="twitter">
            <h2 id="fadein5" class="fadein-before">twitter</h2>

            <a class="twitter-timeline" data-lang="ja" data-width="400" data-height="500" data-align="center" href="https://twitter.com/himatubusi208?ref_src=twsrc%5Etfw">Tweets by himatubusi208</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

          </div>

        </div>
        
      </div>