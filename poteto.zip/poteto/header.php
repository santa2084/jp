<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

  <meta charset=" <?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/boot/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri() ); ?>/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
  <header>
  <p id="icon">|||</p>
  
    <div class="nav">
    <p id="close">✖️</p>
    <ul id="tag">
      <p>【ナビ】</p>
      <li>
        <?php
        wp_nav_menu(
          array(
            'theme_location' => 'nav-menu',
          )
          );
        ?></li>
      </ul>
      <ul id="favorite">
        <p>【おすすめ】</p>
                <li><?php
                      wp_nav_menu(
                        array(
                          'theme_location' => 'side-menu',
                       )
                        );
                      ?>
                </li>
              </ul>
    </div>
    <ul id="nav">
      
    <li>
      <?php
      wp_nav_menu(
        array(
          'theme_location' => 'nav-menu',
        )
        );
      ?></li>
    </ul>
    <p id="title"><?php bloginfo('name'); ?></p>
  </header>