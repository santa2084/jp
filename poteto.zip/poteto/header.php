<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-YTWLF4BMXF"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-YTWLF4BMXF');
</script>

  <meta charset=" <?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri()); ?>/boot/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo esc_url(get_template_directory_uri() ); ?>/style.css">
  

  <!-- seo対策 -->
  <link rel="apple-touch-icon" href="../favicon.ico" sizes="180x180">
  <meta name="format-detection" content="telephone=no">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="keywords" content="高校生ブロガー,ぽてっと">
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <!-- seo対策 -->
  <!-- OGP設定 -->
  <head prefix="og: https://ogp.me/ns#">
  <meta property="og:url" content="https://www.yuublog-8.com/" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="ぽてっと-BLOG" />
  <meta property="og:description" content="高校生ブロガーぽてっとのメインホームです。気軽に覗いていってください！" />
  <meta property="og:site_name" content="potteto-BLOG" />
  <meta property="og:image" content="https://www.yuublog-8.com/images/06.webp" />

  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:site" content="@himatubusi208" />

  <meta property="fb:app_id" content="100088487567197" />
  <!-- OGP設定 -->
  
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
  <header>
    <ul id="nav">
      
    <li>
      <?php
      wp_nav_menu(
        array(
          'theme_location' => 'nav-menu',
        )
        );
      ?></li>
    </ul>
    <p><?php bloginfo('name'); ?></p>
  </header>