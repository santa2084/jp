        <div class="lesson" id="top">
            <a href="#">
              <p class="center">(更新日　12/19)</p>
              <h3>【最新】wordpressでアフェリエイトを始める方法【高校生】</h3>
              <div class="images">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/06.webp">
              </div>
              <p id="fadeinm1" class="fadein-before">今回は,高校生でもできるアフェリエイトの始め方について、まとめてみました！よかったら参考にしてください。</p>
              <div class="read">
                <a>READ MORE</a>
              </div>
            </a>     
        </div>