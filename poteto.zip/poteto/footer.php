<footer><p>copy-right <?php bloginfo('name'); ?></p></footer>
  <script src="<?php echo esc_url(get_template_directory_uri()); ?>/boot/js/bootstrap.min.js"></script>
  <script src="<?php echo esc_url(get_template_directory_uri()); ?>/my.min.js"></script>
  <?php wp_footer(); ?>
</body>
</html>