<?php
function potteto_theme_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_image_size('page_eyecatch',300,300,true);
  register_nav_menus( array(
    'nav-menu' => 'ナビメニュー',
    'side-menu' => 'サイドバー',
    'archive' => 'アーカイブ',
    'main' => 'メイン'
  ));
}
add_action('after_setup_theme','potteto_theme_setup');
?>
