<?php get_header(); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-xs-12">
        <div class="main">
          <h1 id="fadein" class="fadein-before"><?php the_title(); ?></h1>
          <div class="article">
            <?php the_content(); ?>
          </div>        
  
        </div>
       </div>
      
       <?php get_sidebar(); ?>
    </div>
  </div>
  <?php get_footer(); ?>