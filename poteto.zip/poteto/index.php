<?php get_header(); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-xs-12">
        <div class="main">
          <h1><?php bloginfo('name'); ?></h1>
          <?php if(have_posts()) : ?>
            <?php
            while(have_posts()):
              the_post();
              ?>
              <div class="lesson" id="top">
                <div class="arch">
                <?php the_tags(
                '<a><p>','<time></time>','</p></a>'
              ); ?>
                </div>
              
              <div class="cate">
                 <?php the_category(','); ?>
              </div>  

              <h3><?php the_title(); ?></h3>
              <div class="images">
              <?php if(has_post_thumbnail()): ?>
                  <?php the_post_thumbnail('archive_thumbnail'); ?>
                  <?php else: ?>
                    <img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/no.jpg">
                  <?php endif;?>        
              </div>
              <?php the_excerpt(); ?>
              <div class="read">
                <a href="<?php the_permalink(); ?>">READ MORE</a>
              </div>  
           </div>
       <?php endwhile; ?>
       <?php endif; ?>
       <?php the_posts_pagination(
        array(
          'prev_text' => '&lt;<span class="sr-only">前</span>',
          'next_text' => '<span class="sr-only">次</span>&gt;',
        )
       ); ?>
       </div>
      </div>
      <?php get_sidebar(); ?>
    </div>
  </div>
  <?php get_footer(); ?>